﻿using GamesAPiClient.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GamesAPiClient
{
    public partial class Form1 : Form
    {

        public GameRow oldGameRow;

        public Form1()
        {
            InitializeComponent();
        }

        private void DescripcioJocSeleccionat_TextChanged(object sender, EventArgs e)
        {

        }

        private void DescripcioJocSeleccionat_Enter(object sender, EventArgs e)
        {
            //ActiveControl = gamesList;
        }

        private void JocSeleccionatLabel_Click(object sender, EventArgs e)
        {

        }

        private void PuntuacioJocSeleccionat_Click(object sender, EventArgs e)
        {

        }

        private void RedditLogo_Click(object sender, EventArgs e)
        {

        }

        private void VideoLogo_Click(object sender, EventArgs e)
        {

        }
    }
}
